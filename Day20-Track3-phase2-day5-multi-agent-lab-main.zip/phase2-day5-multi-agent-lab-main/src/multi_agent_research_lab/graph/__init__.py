"""Workflow graph skeleton."""
